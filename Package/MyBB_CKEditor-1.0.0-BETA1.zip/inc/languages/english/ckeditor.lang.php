<?php
/**
 * CKEDITOR English Language Pack
 * Copyright 2012 Brian McCloskey, All Rights Reserved
 */

$l['ckeditor_profile_description'] = "Enable WYSIWYG editor for quick reply?";

?>
