﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

(function(){CKEDITOR.plugins.setLang('mybbcode','en',{mybbcode:{codeButton:'Code',phpButton:'PHP',codeTitle:'CODE:',phpTitle:'PHP CODE:'}});})();
