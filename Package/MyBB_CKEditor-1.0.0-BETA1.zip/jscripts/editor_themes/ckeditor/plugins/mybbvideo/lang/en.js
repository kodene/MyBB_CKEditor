﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

(function(){CKEDITOR.plugins.setLang('mybbvideo','en',{mybbvideo:{title:'Video Properties',button:'Video',validateURL:'URL must not be empty.',videoType:'Video Type',dailymotion:'Dailymotion',metacafe:'MetaCafe',vimeo:'Vimeo',yahoo:'Yahoo',myspacetv:'MySpace TV',youtube:'YouTube'}});})();
